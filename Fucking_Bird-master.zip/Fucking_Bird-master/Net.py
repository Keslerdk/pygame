import random
import math


class Sheet:
    input_size = int()
    output_size = int()
    inputs = []
    outputs = []

    def __init__(self, ins, outs):
        self.input_size = 2
        self.output_size = 1
        self.inputs = [0.0] * 2
        self.outputs = [0.0] * 1
        self.load(ins, outs)

    def load(self, ins, outs):
        self.inputs = ins
        self.outputs = outs


class Bird_Sheets:
    count = int()
    lists = []
    input_sizes = int()
    output_sizes = int()

    def __init__(self, list):
        self.lists = list
        self.count = 1
        self.input_sizes = 2
        self.output_sizes = 1

    def print(self):
        print("Count:", self.count, "input sizes:", self.input_sizes, "output sizes:", self.output_sizes)
        for i in range(0, self.count):
            self.lists[i].print()


class Neuron(object):
    id = int()
    layer = int()
    type = str()
    value = float()
    function_type = int()
    mistake = float(0)

    def activation_function(self, x):
        try:
            return 1 / (1 + math.exp(-x))
        except:
            return 0

    def __init__(self, id):
        self.id = id
        self.type = "input"
        self.function_type = 1

    def __str__(self):
        return str(self.value)

    def load(self, mem):  # загрузка из файла
        s = mem.split(" ")
        self.id = int(s[0])
        self.layer = int(s[1])
        self.value = float(s[2])
        self.function_type = int(s[3])
        self.type = str(s[4])

    def show(self):
        print("ID:", self.id, "type:", self.type, "value:", self.value, '\n')


class Neural_Net:
    size_of_net = int()
    layer_count = int()
    speed = float(0.5)
    layer_capacity = []
    neurons = []
    axons = []
    smooth = int(1)
    unique_id = random.randint(0, 100)

    def __init__(self, data):
        self.layer_capacity = data["struct"]
        self.size_of_net = sum(self.layer_capacity)
        self.layer_count = len(self.layer_capacity)

        self.axons = [0] * self.size_of_net
        for i in range(self.size_of_net):
            self.axons[i] = [0] * self.size_of_net

        for i in range(0, self.size_of_net):
            for j in range(0, self.size_of_net):
                self.axons[i][j] = float()

        self.axons = data['weights']

        for i in range(self.size_of_net):
            self.neurons.append(Neuron(i))

        for i in range(0, self.layer_count):
            for j in range(0, self.layer_capacity[i]):
                if i == 0:
                    self.neurons[i].load(str(self.get_id(i, j)) + " " + str(i) + ' 0 3 input')
                elif i == self.layer_count - 1:
                    self.neurons[i].load(str(self.get_id(i, j)) + " " + str(i) + ' 0 3 output')
                else:
                    self.neurons[i].load(str(self.get_id(i, j)) + " " + str(i) + ' 0 3 hidden')

    def load_net(self, memes):
        mem = open(memes, 'r')
        info = mem.readline()
        s = info.split(" ")
        self.size_of_net = int(s[0])
        self.layer_count = int(s[1])
        for i in range(2, self.layer_count + 2):
            self.layer_capacity.append(int(s[i]))

        self.axons = [0] * self.size_of_net
        for i in range(self.size_of_net):
            self.axons[i] = [0] * self.size_of_net

        for i in range(0, self.size_of_net):
            for j in range(0, self.size_of_net):
                self.axons[i][j] = float()

        for i in range(self.size_of_net):
            self.neurons.append(Neuron(i))
        for i in range(0, self.size_of_net):
            self.neurons[i].load(mem)
        mem.close()

    def get_id(self, layer, lid):  # возвращает id исходя из слоя и номера на слое
        s = int(0)
        for i in range(0, layer):
            s += self.layer_capacity[i]
        return s + lid

    def print(self):
        print("Size:", self.size_of_net, "count:", self.layer_count, "capacity:", self.layer_capacity)

        print("Axons:", self.size_of_net, 'x', self.size_of_net)
        for i in range(0, self.size_of_net):
            print(self.axons[i])
        print('\n')
        for i in range(0, self.size_of_net):
            self.neurons[i].show()

    def load_axons(self, heh):  # загрузка аксонов из файла
        axonchiki = open(heh, 'r')
        info = axonchiki.readline()
        if int(info) == self.size_of_net:
            for i in range(0, self.size_of_net):
                info = axonchiki.readline()
                s = info.split(" ")
                for j in range(0, self.size_of_net):
                    self.axons[i][j] = float(s[j])
        axonchiki.close()

    def random_axons(self):  # рандомит аксоны
        for i in range(0, self.size_of_net):
            for j in range(0, self.size_of_net):
                if i >= j:
                    self.axons[i][j] = random.randint(-10000, 10000) / 10000
                    self.axons[j][i] = self.axons[i][j]

    def set_values(self, sheet):  # заливает значения в соответствии с листом
        for i in range(0, len(sheet)):
            self.neurons[i].value = sheet[i]

    def round(self, x):  # округление всех значений до х
        for i in range(0, self.size_of_net):
            self.neurons[i].value = round(self.neurons[i].value, x)

    def is_true(self, inputs, outputs):  # подходит ли сеть под лист
        self.set_values(inputs)
        self.update_values()
        this_values = []
        for i in range(self.get_id(self.layer_count - 1, 0), self.size_of_net):
            this_values.append(round(self.neurons[i].value, self.smooth))
        for i in range(0, self.layer_capacity[self.layer_count - 1]):
            if round(outputs[i], self.smooth) != this_values[i]:
                return False
        return True

    def is_normal(self, inputs, outputs):  # подходит ли сеть под листы
        for i in range(0, len(inputs)):
            if not self.is_true(inputs[i], outputs[i]):
                return False
        return True

    def update_values(self):  # обновляет значения сети
        for i in range(self.size_of_net):
            if not (self.neurons[i].type == "input\n" or self.neurons[i].type == "shift\n"):
                s = float(0)
                for j in range(0, self.layer_capacity[self.neurons[i].layer - 1]):
                    s += self.neurons[self.get_id(self.neurons[i].layer - 1, j)].value * \
                         self.axons[self.neurons[self.get_id(self.neurons[i].layer - 1, j)].id][self.neurons[i].id]
                self.neurons[i].value = self.neurons[i].activation_function(s)

    def get_results(self):
        s = []
        for i in range(0, self.layer_capacity[len(self.layer_capacity) - 1]):
            s.append(self.neurons[self.get_id(len(self.layer_capacity) - 1, i)].value)
        return s

    def zero(self):
        for i in self.neurons:
            i.value = 0.0
        self.axons = [[0.0] * self.size_of_net] * self.size_of_net

    def save_result(self):
        data = {"struct": self.layer_capacity,
                "weights": self.axons}
        return data

    def get_min_max(self):
        mini = 10000
        maxi = -10000
        for i in self.axons:
            for j in i:
                if j > maxi:
                    maxi = j
                elif j < mini:
                    mini = j
        return [mini, maxi]

    def __add__(self, other):
        kek = [self.axons, other.axons]
        weights = [[0] * self.size_of_net] * self.size_of_net

        for i in range(0, self.size_of_net):
            for j in range(0, self.size_of_net):
                weights[i][j] = kek[random.randint(0, 1)][i][j]

        return Neural_Net({"struct": self.layer_capacity, "weights": weights})

    def learn_with_backpropagation(self, inputs, outputs, t):
        for time in range(0, t):
            for i in range(0, len(inputs)):
                self.set_values(inputs[i])
                self.update_values()
                mistakes = [0] * self.layer_count
                for j in range(0, self.layer_count):
                    mistakes[j] = [0] * self.layer_capacity[j]
                for j in range(0, self.layer_capacity[self.layer_count - 1]):
                    a = float(self.neurons[self.get_id(self.layer_count - 1, j)].value)
                    mistakes[self.layer_count - 1][j] = (outputs[i][j] - self.neurons[
                        self.get_id(self.layer_count - 1, j)].value) * a * (1 - a)
                for k in range(self.layer_count - 2, 0, -1):
                    for j in range(0, self.layer_capacity[k]):
                        sum_of_last_layer = float(0)
                        for q in range(0, self.layer_capacity[k + 1]):
                            sum_of_last_layer += mistakes[k + 1][q] * self.axons[self.get_id(k, j)][
                                self.get_id(k + 1, q)]
                        a = float(self.neurons[self.get_id(k, j)].value)
                        mistakes[k][j] = sum_of_last_layer * a * (1 - a)
                for k in range(0, self.layer_count):
                    for q in range(0, self.layer_capacity[k]):
                        self.neurons[self.get_id(k, q)].mistake = mistakes[k][q]
                delta_axons = [[0] * self.size_of_net for t in range(self.size_of_net)]
                for j in range(0, self.size_of_net):
                    for k in range(0, self.size_of_net):
                        delta_axons[j][k] = self.neurons[j].value * self.speed * self.neurons[k].mistake
                        self.axons[j][k] += delta_axons[j][k]
                        self.axons[k][j] = self.axons[j][k]


def learn_with_random(net, anwsers):
    time_taken = int(0)
    while not net.is_normal(anwsers.lists[0].inputs, anwsers.lists[0].outputs):
        net.random_axons()
        net.update_values()
        time_taken += 1
    return time_taken


def show_net(net, anwsers):
    for i in range(0, anwsers.count):
        net.set_values(anwsers, i)
        net.update_values()
        net.print()

# main_net = Neural_Net("Net.struct")  # загружаем сеть из файла
# main_net.load_axons("Net.axons")  # загружаем аксоны
# learn_sheet = Sheets("Learning.list")  # загружаем листы для обучения
# main_net.smooth = 0  # настройка сглаживания
# main_net.random_axons()  # рандомим немного
# main_net.speed = 0.5  # настройка скорости (0 < n < 1)
# print("Time taken:", learn_with_backpropagation(main_net, learn_sheet))
# main_net.save_result("Net.axons")
